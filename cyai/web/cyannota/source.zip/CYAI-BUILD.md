# Embedded CyAI build

Upstream revision: 59d5e86f7e3df7dafd895b4f96e03e29097bc692

The application source is unchanged. For the CyAI web build, use cyai-web-build-package.json as package.json, install its web-only dependencies, provide the FFmpeg 0.12.10 JavaScript and parts manifest under public/ffmpeg, set CYANNOTA_PAGES_BASE=/cyannota/, and run node node_modules/vite/bin/vite.js build --config web/vite.config.ts. FFmpeg WASM is an optional user download and is excluded from the CyAI package.
