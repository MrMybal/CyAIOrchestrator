const { app, BrowserWindow, ClipboardItem, clipboard, dialog, ipcMain, net, protocol, session, shell } = require('electron');
const { randomUUID } = require('node:crypto');
const { constants: fsConstants } = require('node:fs');
const fs = require('node:fs/promises');
const path = require('node:path');
const { fileURLToPath, pathToFileURL } = require('node:url');

const DESKTOP_SCHEME = 'cyannota';
const DESKTOP_ORIGIN = 'cyannota://app';
const DEVELOPMENT_ORIGIN = 'http://127.0.0.1:5174';

protocol.registerSchemesAsPrivileged([
  {
    scheme: DESKTOP_SCHEME,
    privileges: {
      standard: true,
      secure: true,
      supportFetchAPI: true,
      corsEnabled: true,
    },
  },
]);

const hasSingleInstanceLock = app.requestSingleInstanceLock();
if (!hasSingleInstanceLock) {
  app.quit();
}

let mainWindow = null;
let lastSaveDirectory = null;
let lastClipboardTempDirectory = null;
const pendingSavePaths = new Map();
const pendingOpenPaths = [];
const SUPPORTED_OPEN_EXTENSIONS = new Set([
  '.cyannota', '.zip',
  '.png', '.jpg', '.jpeg', '.webp', '.gif',
  '.mp4', '.webm', '.ogg', '.mov', '.m4v',
]);

function mediaTypeForPath(filePath) {
  const extension = path.extname(filePath).toLowerCase();
  return {
    '.cyannota': 'application/x-cyannota',
    '.zip': 'application/zip',
    '.png': 'image/png',
    '.jpg': 'image/jpeg',
    '.jpeg': 'image/jpeg',
    '.webp': 'image/webp',
    '.gif': 'image/gif',
    '.mp4': 'video/mp4',
    '.webm': 'video/webm',
    '.ogg': 'video/ogg',
    '.mov': 'video/quicktime',
    '.m4v': 'video/x-m4v',
  }[extension] || 'application/octet-stream';
}

function launchPathFromArgument(argument) {
  if (typeof argument !== 'string' || !argument.trim()) return null;
  if (argument.startsWith(DESKTOP_ORIGIN)) return null;
  if (argument.toLowerCase().startsWith(DESKTOP_SCHEME + '://')) {
    try {
      const url = new URL(argument);
      if (url.host !== 'open') return null;
      const requestedPath = url.searchParams.get('path');
      return requestedPath && path.isAbsolute(requestedPath) ? path.normalize(requestedPath) : null;
    } catch {
      return null;
    }
  }
  return path.isAbsolute(argument) ? path.normalize(argument) : null;
}

async function supportedLaunchPaths(argumentsList) {
  const candidates = argumentsList
    .map(launchPathFromArgument)
    .filter(Boolean)
    .filter((filePath) => SUPPORTED_OPEN_EXTENSIONS.has(path.extname(filePath).toLowerCase()));
  const unique = [...new Set(candidates)];
  const valid = [];
  for (const filePath of unique) {
    try {
      if ((await fs.stat(filePath)).isFile()) valid.push(filePath);
    } catch {
      // Une intégration peut fournir un chemin supprimé entre la capture et l’ouverture.
    }
  }
  return valid;
}

async function openItemsForPaths(filePaths) {
  const items = [];
  for (const filePath of filePaths) {
    try {
      const content = await fs.readFile(filePath);
      items.push({
        name: path.basename(filePath),
        type: mediaTypeForPath(filePath),
        bytes: content.buffer.slice(content.byteOffset, content.byteOffset + content.byteLength),
      });
    } catch (error) {
      console.warn('Impossible d’ouvrir le fichier transmis à CyAnnota', filePath, error);
    }
  }
  return items;
}

async function sendOpenPaths(filePaths) {
  if (!mainWindow || mainWindow.isDestroyed() || mainWindow.webContents.isLoading()) {
    pendingOpenPaths.push(...filePaths);
    return;
  }
  const items = await openItemsForPaths(filePaths);
  if (items.length) mainWindow.webContents.send('cyannota:open-files', items);
}

async function readClipboardOpenItems() {
  const paths = [];
  const clipboardItems = await clipboard.read();
  for (const item of clipboardItems) {
    if (!item.types.includes('text/uri-list')) continue;
    const blob = await item.getType('text/uri-list');
    if (!blob || typeof blob.text !== 'function') continue;
    const uriList = await blob.text();
    for (const line of uriList.split(/\r?\n/)) {
      const value = line.trim();
      if (!value || value.startsWith('#')) continue;
      try {
        const url = new URL(value);
        if (url.protocol === 'file:') paths.push(fileURLToPath(url));
      } catch {
        // Ignore les entrées de presse-papiers qui ne sont pas des fichiers valides.
      }
    }
  }
  const supportedPaths = await supportedLaunchPaths(paths);
  return openItemsForPaths(supportedPaths);
}

async function queueLaunchArguments(argumentsList) {
  const filePaths = await supportedLaunchPaths(argumentsList);
  if (filePaths.length) await sendOpenPaths(filePaths);
}

async function flushPendingOpenPaths() {
  if (!pendingOpenPaths.length) return;
  const filePaths = [...new Set(pendingOpenPaths.splice(0))];
  await sendOpenPaths(filePaths);
}

function preferencesFilePath() {
  return path.join(app.getPath('userData'), 'desktop-preferences.json');
}

async function loadDesktopPreferences() {
  try {
    const preferences = JSON.parse(await fs.readFile(preferencesFilePath(), 'utf8'));
    const directory = preferences?.lastSaveDirectory;
    if (typeof directory !== 'string' || !path.isAbsolute(directory)) return;
    const stats = await fs.stat(directory);
    if (stats.isDirectory()) lastSaveDirectory = directory;
  } catch {
    lastSaveDirectory = null;
  }
}

async function rememberSaveDirectory(filePath) {
  const directory = path.dirname(filePath);
  lastSaveDirectory = directory;
  await fs.mkdir(app.getPath('userData'), { recursive: true });
  await fs.writeFile(
    preferencesFilePath(),
    JSON.stringify({ lastSaveDirectory: directory }, null, 2),
    'utf8',
  );
}

function isTrustedAppUrl(rawUrl) {
  try {
    const url = new URL(rawUrl);
    if (app.isPackaged) {
      return url.protocol === DESKTOP_SCHEME + ':' && url.host === 'app';
    }
    return url.origin === DEVELOPMENT_ORIGIN;
  } catch {
    return false;
  }
}

function registerDesktopProtocol() {
  const rendererRoot = path.resolve(__dirname, 'dist', 'renderer');

  protocol.handle(DESKTOP_SCHEME, (request) => {
    const requestUrl = new URL(request.url);
    const relativePath = decodeURIComponent(requestUrl.pathname).replace(/^\/+/, '') || 'index.html';
    const requestedFile = path.resolve(rendererRoot, relativePath);
    const pathFromRoot = path.relative(rendererRoot, requestedFile);

    if (pathFromRoot.startsWith('..') || path.isAbsolute(pathFromRoot)) {
      return new Response('Fichier introuvable', { status: 404 });
    }

    return net.fetch(pathToFileURL(requestedFile).toString());
  });
}

function assertTrustedSender(event) {
  const senderUrl = event.senderFrame?.url || event.sender.getURL();
  if (!isTrustedAppUrl(senderUrl)) {
    throw new Error('Origine de sauvegarde refusée');
  }
}

function safeDesktopFileName(name, fallback = 'cyannota-espace-de-travail.zip') {
  return (
    typeof name === 'string'
      ? path.basename(name).replace(/[<>:"/\\|?*\u0000-\u001f]/g, '-')
      : fallback
  ) || fallback;
}

function saveDialogOptions(name) {
  const suggestedName = safeDesktopFileName(name);
  const extension = path.extname(suggestedName).toLowerCase();
  const filters =
    extension === '.cyannota'
      ? [{ name: 'Projet CyAnnota', extensions: ['cyannota'] }]
      : extension === '.zip'
      ? [{ name: 'Archive CyAnnota', extensions: ['zip'] }]
      : extension === '.png'
        ? [{ name: 'Image PNG', extensions: ['png'] }]
        : [{ name: 'Tous les fichiers', extensions: ['*'] }];

  return {
    title: 'Enregistrer avec CyAnnota',
    defaultPath: path.join(lastSaveDirectory || app.getPath('downloads'), suggestedName),
    filters,
    properties: ['createDirectory'],
  };
}

async function nextAvailableSavePath(requestedPath) {
  const extension = path.extname(requestedPath);
  const basePath = requestedPath.slice(0, requestedPath.length - extension.length);
  let index = 0;
  while (true) {
    const candidate = index === 0 ? requestedPath : basePath + ' (' + index + ')' + extension;
    try {
      await fs.access(candidate);
      index += 1;
    } catch (error) {
      if (error?.code === 'ENOENT') {
        return { filePath: candidate, renamed: index > 0 };
      }
      throw error;
    }
  }
}

async function copyFileReferenceToClipboard(filePath) {
  await clipboard.write([
    new ClipboardItem({
      'text/uri-list': pathToFileURL(filePath).href,
    }),
  ]);
}

function getPendingSave(event, payload) {
  const token = typeof payload?.token === 'string' ? payload.token : '';
  const pending = pendingSavePaths.get(token);
  if (!pending || pending.senderId !== event.sender.id) {
    throw new Error('La destination de sauvegarde a expiré. Recommencez l’enregistrement.');
  }
  return { token, pending };
}

async function closePendingHandle(pending) {
  if (!pending.handle) return;
  const handle = pending.handle;
  pending.handle = null;
  await handle.close();
}

async function abortPendingSave(token, pending) {
  try {
    await closePendingHandle(pending);
  } finally {
    if (pending.clipboardDirectory) {
      await fs.rm(pending.clipboardDirectory, { recursive: true, force: true }).catch(() => undefined);
    } else {
      await fs.rm(pending.tempPath, { force: true }).catch(() => undefined);
    }
    pendingSavePaths.delete(token);
  }
}

async function writeCompleteBuffer(handle, bytes) {
  let offset = 0;
  while (offset < bytes.byteLength) {
    const result = await handle.write(bytes, offset, bytes.byteLength - offset, null);
    if (!result.bytesWritten) {
      throw new Error('L’écriture du fichier s’est interrompue sans explication.');
    }
    offset += result.bytesWritten;
  }
}

function saveErrorDetail(error, filePath) {
  const detail = error instanceof Error ? error.message : String(error);
  return `Impossible d’enregistrer « ${filePath} ». ${detail}`;
}

function registerDesktopIpc() {
  ipcMain.handle('cyannota:read-clipboard-files', async (event) => {
    assertTrustedSender(event);
    return readClipboardOpenItems();
  });

  ipcMain.handle('cyannota:choose-save-file', async (event, payload) => {
    assertTrustedSender(event);

    const owner = BrowserWindow.fromWebContents(event.sender) || mainWindow;
    const result = await dialog.showSaveDialog(owner, saveDialogOptions(payload?.name));
    if (result.canceled || !result.filePath) {
      return { canceled: true };
    }

    const now = Date.now();
    const target = await nextAvailableSavePath(result.filePath);
    for (const [expiredToken, expiredPending] of pendingSavePaths) {
      if (now - expiredPending.createdAt > 10 * 60 * 1000) {
        await abortPendingSave(expiredToken, expiredPending);
      }
    }

    const token = randomUUID();
    pendingSavePaths.set(token, {
      filePath: target.filePath,
      requestedPath: result.filePath,
      renamed: target.renamed,
      tempPath: path.join(app.getPath('temp'), `cyannota-${token}.tmp`),
      senderId: event.sender.id,
      createdAt: now,
      handle: null,
      bytesWritten: 0,
    });
    return {
      canceled: false,
      token,
      fileName: path.basename(target.filePath),
      renamed: target.renamed,
    };
  });

  ipcMain.handle('cyannota:prepare-clipboard-file', async (event, payload) => {
    assertTrustedSender(event);
    const token = randomUUID();
    const clipboardDirectory = path.join(app.getPath('temp'), 'CyAnnota Clipboard', token);
    const fileName = safeDesktopFileName(payload?.name);
    const filePath = path.join(clipboardDirectory, fileName);
    await fs.mkdir(clipboardDirectory, { recursive: true });
    pendingSavePaths.set(token, {
      filePath,
      requestedPath: filePath,
      renamed: false,
      tempPath: filePath,
      clipboardDirectory,
      clipboardOnly: true,
      senderId: event.sender.id,
      createdAt: Date.now(),
      handle: null,
      bytesWritten: 0,
    });
    return { token, fileName };
  });

  ipcMain.handle('cyannota:begin-save-file', async (event, payload) => {
    assertTrustedSender(event);
    const { pending } = getPendingSave(event, payload);
    if (pending.handle) {
      throw new Error('Une écriture est déjà en cours pour ce fichier.');
    }

    try {
      pending.handle = await fs.open(pending.tempPath, 'w');
      pending.bytesWritten = 0;
      return { started: true };
    } catch (error) {
      throw new Error(saveErrorDetail(error, pending.filePath));
    }
  });

  ipcMain.handle('cyannota:write-save-chunk', async (event, payload) => {
    assertTrustedSender(event);
    const { pending } = getPendingSave(event, payload);
    if (!pending.handle) {
      throw new Error('L’écriture du fichier n’a pas été initialisée.');
    }

    const base64 = payload?.base64;
    if (
      typeof base64 !== 'string' ||
      base64.length === 0 ||
      base64.length > 2 * 1024 * 1024 ||
      base64.length % 4 !== 0 ||
      !/^[A-Za-z0-9+/]*={0,2}$/.test(base64)
    ) {
      throw new Error('Un bloc de données du ZIP est invalide.');
    }

    const bytes = Buffer.from(base64, 'base64');
    if (!bytes.byteLength) {
      throw new Error('Un bloc de données du ZIP est vide.');
    }

    try {
      await writeCompleteBuffer(pending.handle, bytes);
      pending.bytesWritten += bytes.byteLength;
      return { written: bytes.byteLength };
    } catch (error) {
      throw new Error(saveErrorDetail(error, pending.filePath));
    }
  });

  ipcMain.handle('cyannota:finish-save-file', async (event, payload) => {
    assertTrustedSender(event);
    const { token, pending } = getPendingSave(event, payload);
    if (!pending.handle) {
      throw new Error('Aucune écriture n’est en cours pour ce fichier.');
    }

    try {
      await pending.handle.sync();
      await closePendingHandle(pending);
      if (!pending.bytesWritten) {
        throw new Error('Le fichier généré est vide.');
      }
      const target = await nextAvailableSavePath(pending.requestedPath || pending.filePath);
      pending.filePath = target.filePath;
      pending.renamed = pending.renamed || target.renamed;
      await fs.copyFile(pending.tempPath, pending.filePath, fsConstants.COPYFILE_EXCL);
      await fs.rm(pending.tempPath, { force: true });
      await rememberSaveDirectory(pending.filePath).catch((error) => {
        console.warn('Impossible de mémoriser le dossier de sauvegarde', error);
      });

      let copied = false;
      let copyError;
      if (payload?.copyToClipboard === true) {
        try {
          await copyFileReferenceToClipboard(pending.filePath);
          copied = true;
        } catch (error) {
          copyError = error instanceof Error ? error.message : String(error);
        }
      }

      pendingSavePaths.delete(token);
      return {
        saved: true,
        bytesWritten: pending.bytesWritten,
        copied,
        copyError,
        fileName: path.basename(pending.filePath),
        renamed: pending.renamed === true,
      };
    } catch (error) {
      await abortPendingSave(token, pending);
      throw new Error(saveErrorDetail(error, pending.filePath));
    }
  });

  ipcMain.handle('cyannota:finish-clipboard-file', async (event, payload) => {
    assertTrustedSender(event);
    const { token, pending } = getPendingSave(event, payload);
    if (!pending.clipboardOnly || !pending.clipboardDirectory) {
      throw new Error('Ce transfert n’est pas destiné au presse-papiers.');
    }
    if (!pending.handle) {
      throw new Error('Aucune écriture n’est en cours pour ce fichier.');
    }

    try {
      await pending.handle.sync();
      await closePendingHandle(pending);
      if (!pending.bytesWritten) throw new Error('Le fichier généré est vide.');
      await copyFileReferenceToClipboard(pending.filePath);
      pendingSavePaths.delete(token);

      const previousDirectory = lastClipboardTempDirectory;
      lastClipboardTempDirectory = pending.clipboardDirectory;
      if (previousDirectory && previousDirectory !== pending.clipboardDirectory) {
        await fs.rm(previousDirectory, { recursive: true, force: true }).catch(() => undefined);
      }

      return {
        copied: true,
        bytesWritten: pending.bytesWritten,
        fileName: path.basename(pending.filePath),
      };
    } catch (error) {
      await abortPendingSave(token, pending);
      throw new Error(saveErrorDetail(error, pending.filePath));
    }
  });

  ipcMain.handle('cyannota:abort-save-file', async (event, payload) => {
    assertTrustedSender(event);
    const token = typeof payload?.token === 'string' ? payload.token : '';
    const pending = pendingSavePaths.get(token);
    if (!pending) return { aborted: true };
    if (pending.senderId !== event.sender.id) {
      throw new Error('Cette sauvegarde appartient à une autre fenêtre.');
    }
    await abortPendingSave(token, pending);
    return { aborted: true };
  });

  ipcMain.handle('cyannota:show-error-message', async (event, payload) => {
    assertTrustedSender(event);
    const owner = BrowserWindow.fromWebContents(event.sender) || mainWindow;
    const title = typeof payload?.title === 'string' ? payload.title.slice(0, 120) : 'CyAnnota - erreur';
    const message =
      typeof payload?.message === 'string'
        ? payload.message.slice(0, 300)
        : 'L’enregistrement a échoué.';
    const detail =
      typeof payload?.detail === 'string'
        ? payload.detail.slice(0, 4000)
        : 'Aucun détail technique n’est disponible.';

    await dialog.showMessageBox(owner, {
      type: 'error',
      title,
      message,
      detail,
      buttons: ['Fermer'],
      defaultId: 0,
      noLink: true,
    });
    return { shown: true };
  });
}
function createMainWindow() {
  const window = new BrowserWindow({
    width: 1600,
    height: 1000,
    minWidth: 1080,
    minHeight: 680,
    show: false,
    autoHideMenuBar: true,
    backgroundColor: '#151514',
    title: 'CyAnnota',
    icon: path.join(__dirname, 'dist', 'renderer', 'cyannota-logo.png'),
    webPreferences: {
      preload: path.join(__dirname, 'preload.cjs'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
      webSecurity: true,
    },
  });

  const developmentUrl = process.env.CYANNOTA_RENDERER_URL;
  const targetUrl =
    !app.isPackaged && developmentUrl === DEVELOPMENT_ORIGIN
      ? developmentUrl
      : DESKTOP_ORIGIN + '/index.html';

  window.once('ready-to-show', () => window.show());
  window.webContents.on('did-finish-load', () => {
    flushPendingOpenPaths().catch((error) => {
      console.warn('Impossible de transmettre les fichiers en attente', error);
    });
  });
  window.webContents.setWindowOpenHandler(({ url }) => {
    if (url.startsWith('https://')) {
      shell.openExternal(url).catch(() => undefined);
    }
    return { action: 'deny' };
  });
  window.webContents.on('will-navigate', (event, url) => {
    if (isTrustedAppUrl(url)) return;
    event.preventDefault();
    if (url.startsWith('https://')) {
      shell.openExternal(url).catch(() => undefined);
    }
  });

  window.loadURL(targetUrl);
  window.on('closed', () => {
    if (mainWindow === window) mainWindow = null;
  });

  return window;
}

app.whenReady().then(async () => {
  app.setAppUserModelId('com.cyberalien.cyannota');
  if (app.isPackaged) app.setAsDefaultProtocolClient(DESKTOP_SCHEME);
  await loadDesktopPreferences();

  if (app.isPackaged) {
    registerDesktopProtocol();
  }
  registerDesktopIpc();

  session.defaultSession.setPermissionRequestHandler((_webContents, permission, callback, details) => {
    const requestingUrl = details.requestingUrl || details.securityOrigin || '';
    callback(permission === 'clipboard-read' && isTrustedAppUrl(requestingUrl));
  });

  mainWindow = createMainWindow();
  await queueLaunchArguments(process.argv.slice(1));

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) {
      mainWindow = createMainWindow();
    }
  });
});

app.on('second-instance', (_event, commandLine) => {
  queueLaunchArguments(commandLine).catch((error) => {
    console.warn('Impossible de traiter la demande d’ouverture', error);
  });
  if (!mainWindow) return;
  if (mainWindow.isMinimized()) mainWindow.restore();
  mainWindow.show();
  mainWindow.focus();
});

app.on('open-file', (event, filePath) => {
  event.preventDefault();
  queueLaunchArguments([filePath]).catch((error) => {
    console.warn('Impossible de traiter le fichier macOS', error);
  });
});

app.on('open-url', (event, url) => {
  event.preventDefault();
  queueLaunchArguments([url]).catch((error) => {
    console.warn('Impossible de traiter le lien CyAnnota', error);
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});
