import { cpSync, mkdirSync, readFileSync, writeFileSync, readdirSync } from 'node:fs'
import { execFileSync } from 'node:child_process'
import { zipSync } from 'fflate'

const pkg = JSON.parse(readFileSync('package.json', 'utf8'))
const root = 'release/plugin'
mkdirSync(root, { recursive: true })
cpSync('dist', root, { recursive: true })
cpSync('LICENSE', `${root}/LICENSE.txt`)
const manifest = { id: 'cymd', name: 'CyMD', type: 'document', enabled: false,
  version: pkg.version, license: pkg.license, entry: 'index.html',
  protocol: 'cymd.integration', protocolVersion: 1, extensions: ['.cymd', '.md', '.markdown'], button: 'Ouvrir CyMD' }
writeFileSync(`${root}/plugin.json`, JSON.stringify(manifest, null, 2) + '\n')
// Ship the corresponding source, including current uncommitted integration changes.
const tracked = execFileSync('git', ['-c', `safe.directory=${process.cwd().replaceAll('\\', '/')}`, 'ls-files', '--cached', '--others', '--exclude-standard', '-z'], { encoding: 'utf8' }).split('\0').filter(Boolean)
const files = new Set([...tracked, 'src/platform/embedded.ts', 'scripts/build-plugin.mjs', 'docs/integration.md'])
const source = {}
for (const file of files) source[file] = readFileSync(file)
writeFileSync(`${root}/source.zip`, zipSync(source))
const bundle = {}
function collect(dir, prefix = '') {
  for (const entry of readdirSync(dir, { withFileTypes: true })) {
    const name = prefix + entry.name
    if (entry.isDirectory()) collect(`${dir}/${entry.name}`, `${name}/`)
    else bundle[name] = readFileSync(`${dir}/${entry.name}`)
  }
}
collect(root)
writeFileSync('release/CyMD-plugin.zip', zipSync(bundle))
console.log(`Plugin built in ${root}`)
